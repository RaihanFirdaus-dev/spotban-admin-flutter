import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:get/get.dart';
import 'package:latlong2/latlong.dart';
import 'workshop_controller.dart';

class WorkshopFormView extends StatelessWidget {
  WorkshopFormView({super.key});

  // Controller sudah dibuat oleh WorkshopBinding sebelum View dibangun
  final WorkshopController _ctrl = Get.find<WorkshopController>();
  final _formKey = GlobalKey<FormState>();

  static const _defaultCenter = LatLng(-6.2088, 106.8456);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: cs.surfaceContainerLowest,
      appBar: AppBar(
        title: Obx(
          () => Text(_ctrl.isEditMode ? 'Edit Bengkel' : 'Tambah Bengkel'),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => _confirmBack(context),
        ),
      ),

      // Submit button sticky di bawah agar selalu terlihat
      bottomNavigationBar: _SubmitBar(ctrl: _ctrl, formKey: _formKey),

      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            _SectionCard(
              title: 'Informasi Dasar',
              icon: Icons.info_outline_rounded,
              children: [
                TextFormField(
                  controller: _ctrl.nameCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Nama Bengkel',
                    hintText: 'Contoh: Bengkel Maju Jaya',
                    prefixIcon: Icon(Icons.storefront_outlined),
                  ),
                  textCapitalization: TextCapitalization.words,
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _ctrl.descCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Deskripsi',
                    hintText: 'Ceritakan keunggulan bengkel ini...',
                    prefixIcon: Icon(Icons.description_outlined),
                    alignLabelWithHint: true,
                  ),
                  maxLines: 3,
                  textCapitalization: TextCapitalization.sentences,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _ctrl.addressCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Alamat Lengkap',
                    hintText: 'Jl. Contoh No. 10, Kota',
                    prefixIcon: Icon(Icons.place_outlined),
                    alignLabelWithHint: true,
                  ),
                  maxLines: 2,
                  textCapitalization: TextCapitalization.sentences,
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _ctrl.priceCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Harga Mulai',
                    hintText: '50000',
                    prefixIcon: Icon(Icons.payments_outlined),
                    prefixText: 'Rp ',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'Wajib diisi';
                    if (int.tryParse(v.trim()) == null) return 'Angka saja';
                    return null;
                  },
                ),
              ],
            ),
            const SizedBox(height: 12),

            _SectionCard(
              title: 'Tipe Kendaraan',
              icon: Icons.directions_car_outlined,
              children: [
                Obx(
                  () => Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: _ctrl.vehicleTypes.keys.map((type) {
                      final selected = _ctrl.vehicleTypes[type]!;
                      return FilterChip(
                        label: Text(type),
                        selected: selected,
                        avatar: selected
                            ? null
                            : const Icon(Icons.add, size: 14),
                        onSelected: (_) => _ctrl.toggleVehicle(type),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            _SectionCard(
              title: 'Jenis Layanan',
              icon: Icons.build_outlined,
              children: [
                Obx(
                  () => Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: _ctrl.serviceTypes.keys.map((type) {
                      final selected = _ctrl.serviceTypes[type]!;
                      return FilterChip(
                        label: Text(type),
                        selected: selected,
                        avatar: selected
                            ? null
                            : const Icon(Icons.add, size: 14),
                        onSelected: (_) => _ctrl.toggleService(type),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            _SectionCard(
              title: 'Foto Bengkel',
              icon: Icons.photo_library_outlined,
              trailing: Obx(() {
                final total =
                    _ctrl.existingPhotoUrls.length +
                    _ctrl.selectedImages.length;
                return total > 0
                    ? _Badge('$total foto')
                    : const SizedBox.shrink();
              }),
              children: [
                // Foto lama tersimpan di database
                Obx(() {
                  if (_ctrl.existingPhotoUrls.isEmpty) {
                    return const SizedBox.shrink();
                  }
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _PhotoSubtitle('Foto tersimpan'),
                      const SizedBox(height: 6),
                      _PhotoStrip(
                        count: _ctrl.existingPhotoUrls.length,
                        itemBuilder: (i) {
                          final url = _ctrl.existingPhotoUrls[i];
                          return _PhotoThumb(
                            child: Image.network(
                              url,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) =>
                                  const Icon(Icons.broken_image_outlined),
                            ),
                            onRemove: () => _ctrl.removeExistingPhoto(url),
                          );
                        },
                      ),
                      const SizedBox(height: 12),
                    ],
                  );
                }),

                // Foto baru yang dipilih dari galeri
                Obx(() {
                  if (_ctrl.selectedImages.isEmpty) {
                    return const SizedBox.shrink();
                  }
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _PhotoSubtitle('Foto baru'),
                      const SizedBox(height: 6),
                      _PhotoStrip(
                        count: _ctrl.selectedImages.length,
                        itemBuilder: (i) => _PhotoThumb(
                          child: Image.file(
                            File(_ctrl.selectedImages[i].path),
                            fit: BoxFit.cover,
                          ),
                          onRemove: () => _ctrl.removeNewImage(i),
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                  );
                }),

                // Tombol pilih foto
                OutlinedButton.icon(
                  onPressed: _ctrl.pickImages,
                  icon: const Icon(Icons.add_photo_alternate_outlined),
                  label: const Text('Pilih dari Galeri'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 44),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // ── Peta ────────────────────────────────────────────────────────
            _SectionCard(
              title: 'Lokasi Bengkel',
              icon: Icons.map_outlined,
              children: [
                // Info koordinat yang sudah dipilih
                Obx(() {
                  final loc = _ctrl.selectedLocation.value;
                  return Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: loc != null
                          ? Colors.green.shade50
                          : Colors.orange.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: loc != null
                            ? Colors.green.shade200
                            : Colors.orange.shade200,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          loc != null
                              ? Icons.check_circle_outline
                              : Icons.touch_app_outlined,
                          size: 16,
                          color: loc != null
                              ? Colors.green.shade700
                              : Colors.orange.shade700,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            loc != null
                                ? 'Lat ${loc.latitude.toStringAsFixed(6)}, '
                                      'Lng ${loc.longitude.toStringAsFixed(6)}'
                                : 'Ketuk peta untuk memilih lokasi',
                            style: TextStyle(
                              fontSize: 12,
                              color: loc != null
                                  ? Colors.green.shade800
                                  : Colors.orange.shade800,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
                const SizedBox(height: 10),

                // Flutter Map
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    height: 280,
                    child: Obx(() {
                      final loc = _ctrl.selectedLocation.value;
                      final center = loc ?? _defaultCenter;

                      return FlutterMap(
                        // ValueKey(center) → rebuild peta saat mode edit
                        // pertama kali mendapat koordinat (null → LatLng)
                        key: ValueKey(center),
                        options: MapOptions(
                          initialCenter: center,
                          initialZoom: loc != null ? 15 : 12,
                          onTap: (_, latLng) =>
                              _ctrl.selectedLocation.value = latLng,
                        ),
                        children: [
                          TileLayer(
                            urlTemplate:
                                'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                            userAgentPackageName: 'com.spotban.admin',
                          ),
                          if (loc != null)
                            MarkerLayer(
                              markers: [
                                Marker(
                                  point: loc,
                                  width: 48,
                                  height: 48,
                                  child: const Icon(
                                    Icons.location_pin,
                                    color: Colors.red,
                                    size: 44,
                                  ),
                                ),
                              ],
                            ),
                        ],
                      );
                    }),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  // Dialog konfirmasi saat user tekan Back di mode Edit
  void _confirmBack(BuildContext ctx) {
    if (!_ctrl.isEditMode) {
      Get.back();
      return;
    }
    showDialog(
      context: ctx,
      builder: (_) => AlertDialog(
        title: const Text('Tinggalkan halaman?'),
        content: const Text('Perubahan yang belum disimpan akan hilang.'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Tetap di sini'),
          ),
          FilledButton(
            onPressed: () {
              Get.back(); // tutup dialog
              Get.back(); // kembali ke dashboard
            },
            child: const Text('Tinggalkan'),
          ),
        ],
      ),
    );
  }
}

// ── Submit Bar ───────────────────────────────────────────────────────────────

class _SubmitBar extends StatelessWidget {
  final WorkshopController ctrl;
  final GlobalKey<FormState> formKey;
  const _SubmitBar({required this.ctrl, required this.formKey});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: Obx(
          () => ctrl.isLoading.value
              ? const Center(child: CircularProgressIndicator())
              : ElevatedButton.icon(
                  onPressed: () {
                    if (formKey.currentState!.validate()) {
                      ctrl.submitWorkshop();
                    }
                  },
                  icon: Icon(
                    ctrl.isEditMode
                        ? Icons.save_outlined
                        : Icons.add_circle_outline,
                  ),
                  label: Text(
                    ctrl.isEditMode ? 'Simpan Perubahan' : 'Tambah Bengkel',
                  ),
                ),
        ),
      ),
    );
  }
}

// ── Section Card ─────────────────────────────────────────────────────────────

class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;
  final Widget? trailing;

  const _SectionCard({
    required this.title,
    required this.icon,
    required this.children,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header section
            Row(
              children: [
                Icon(icon, size: 18, color: cs.primary),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: cs.onSurface,
                  ),
                ),
                if (trailing != null) ...[const Spacer(), trailing!],
              ],
            ),
            Divider(
              height: 16,
              thickness: 1,
              color: cs.outlineVariant.withOpacity(0.5),
            ),
            ...children,
          ],
        ),
      ),
    );
  }
}

// ── Photo Helpers ─────────────────────────────────────────────────────────────

class _PhotoSubtitle extends StatelessWidget {
  final String text;
  const _PhotoSubtitle(this.text);

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: Theme.of(context).textTheme.labelSmall?.copyWith(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
    ),
  );
}

class _PhotoStrip extends StatelessWidget {
  final int count;
  final Widget Function(int) itemBuilder;
  const _PhotoStrip({required this.count, required this.itemBuilder});

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 90,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      itemCount: count,
      separatorBuilder: (_, __) => const SizedBox(width: 8),
      itemBuilder: (_, i) => itemBuilder(i),
    ),
  );
}

class _PhotoThumb extends StatelessWidget {
  final Widget child;
  final VoidCallback onRemove;
  const _PhotoThumb({required this.child, required this.onRemove});

  @override
  Widget build(BuildContext context) => Stack(
    children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: SizedBox(width: 90, height: 90, child: child),
      ),
      Positioned(
        top: 4,
        right: 4,
        child: GestureDetector(
          onTap: onRemove,
          child: Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(Icons.close, size: 14, color: Colors.white),
          ),
        ),
      ),
    ],
  );
}

class _Badge extends StatelessWidget {
  final String label;
  const _Badge(this.label);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: cs.primaryContainer,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          color: cs.onPrimaryContainer,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
