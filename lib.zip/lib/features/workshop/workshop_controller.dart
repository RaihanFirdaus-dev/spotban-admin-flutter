import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../dashboard/dashboard_controller.dart';

class WorkshopController extends GetxController {
  final _supabase = Supabase.instance.client;
  final _picker = ImagePicker();
  static const _bucket = 'workshop-photos';

  // ── TextEditingControllers (dikelola di sini agar auto-populate bersih) ──
  final nameCtrl = TextEditingController();
  final descCtrl = TextEditingController();
  final addressCtrl = TextEditingController();
  final priceCtrl = TextEditingController();

  // ── Observable State ──────────────────────────────────────────────────────
  final isLoading = false.obs;
  final selectedImages = <XFile>[].obs;
  final existingPhotoUrls = <String>[].obs;
  final selectedLocation = Rxn<LatLng>();

  final vehicleTypes = <String, bool>{
    'Motor': false,
    'Mobil': false,
    'Truk': false,
  }.obs;

  final serviceTypes = <String, bool>{
    'Ganti Oli': false,
    'Tune Up': false,
    'Cuci': false,
    'Ban': false,
    'Body Repair': false,
  }.obs;

  // URL foto lama yang sudah dihapus user — pending commit saat submit
  final _removedPhotoUrls = <String>[];

  // Data bengkel yang sedang diedit (null = mode Tambah)
  Workshop? editingWorkshop;
  bool get isEditMode => editingWorkshop != null;

  // ── Lifecycle ─────────────────────────────────────────────────────────────
  @override
  void onInit() {
    super.onInit();

    // Get.arguments di-set oleh WorkshopBinding sebelum onInit dipanggil
    if (Get.arguments is Workshop) {
      editingWorkshop = Get.arguments as Workshop;
      _applyEditData();
    }
  }

  @override
  void onClose() {
    // Pastikan TextControllers di-dispose agar tidak ada memory leak
    nameCtrl.dispose();
    descCtrl.dispose();
    addressCtrl.dispose();
    priceCtrl.dispose();
    super.onClose();
  }

  /// Isi semua state dari data bengkel lama — SINKRON untuk fields & lokasi,
  /// ASYNC untuk foto (butuh network call ke workshop_photos).
  void _applyEditData() {
    final w = editingWorkshop!;

    // Pre-populate text fields langsung (tidak perlu postFrameCallback)
    nameCtrl.text = w.name;
    descCtrl.text = w.description ?? '';
    addressCtrl.text = w.address;
    priceCtrl.text = (w.priceStart ?? 0).toString();

    // Pre-populate lokasi → peta langsung tampilkan marker
    if (w.latitude != null && w.longitude != null) {
      selectedLocation.value = LatLng(w.latitude!, w.longitude!);
    }

    // Pre-populate checkbox types
    for (final t in (w.vehicleTypes ?? <String>[])) {
      if (vehicleTypes.containsKey(t)) vehicleTypes[t] = true;
    }
    for (final s in (w.serviceTypes ?? <String>[])) {
      if (serviceTypes.containsKey(s)) serviceTypes[s] = true;
    }

    // Fetch foto async
    _fetchExistingPhotos(w.id);
  }

  Future<void> _fetchExistingPhotos(String workshopId) async {
    try {
      final rows = await _supabase
          .from('workshop_photos')
          .select('photo_url')
          .eq('workshop_id', workshopId)
          .order('is_primary', ascending: false);

      existingPhotoUrls.value = (rows as List)
          .map((r) => r['photo_url'] as String)
          .toList();
    } catch (_) {
      // Non-critical — form tetap bisa dipakai meski foto gagal dimuat
    }
  }

  // ── Image Picker ──────────────────────────────────────────────────────────
  Future<void> pickImages() async {
    final picked = await _picker.pickMultiImage(imageQuality: 75);
    if (picked.isNotEmpty) selectedImages.addAll(picked);
  }

  void removeNewImage(int index) => selectedImages.removeAt(index);

  /// Tandai foto lama untuk dihapus saat submit (belum dihapus sekarang
  /// agar user masih bisa cancel)
  void removeExistingPhoto(String url) {
    existingPhotoUrls.remove(url);
    _removedPhotoUrls.add(url);
  }

  // ── Storage Upload ────────────────────────────────────────────────────────
  Future<String> _uploadImage(XFile xFile, String workshopId) async {
    final file = File(xFile.path);
    final ext = xFile.path.split('.').last;
    final storagePath = '$workshopId/${const Uuid().v4()}.$ext';

    await _supabase.storage
        .from(_bucket)
        .upload(
          storagePath,
          file,
          fileOptions: const FileOptions(upsert: false),
        );

    return _supabase.storage.from(_bucket).getPublicUrl(storagePath);
  }

  // ── Hapus foto lama dari Storage & DB ────────────────────────────────────
  Future<void> _commitRemovedPhotos() async {
    for (final url in _removedPhotoUrls) {
      try {
        await _supabase.from('workshop_photos').delete().eq('photo_url', url);

        // Ekstrak storagePath dari URL publik:
        // format: .../storage/v1/object/public/{bucket}/{path}
        final uri = Uri.parse(url);
        final segments = uri.pathSegments;
        final bucketIndex = segments.indexOf(_bucket);
        if (bucketIndex != -1 && bucketIndex < segments.length - 1) {
          final storagePath = segments.sublist(bucketIndex + 1).join('/');
          await _supabase.storage.from(_bucket).remove([storagePath]);
        }
      } catch (_) {
        // Lanjutkan meski satu foto gagal
      }
    }
    _removedPhotoUrls.clear();
  }

  // ── RPC Insert ────────────────────────────────────────────────────────────
  Future<String> _insertWorkshopRpc() async {
    final result = await _supabase.rpc(
      'insert_workshop',
      params: {
        'p_name': nameCtrl.text.trim(),
        'p_description': descCtrl.text.trim(),
        'p_address': addressCtrl.text.trim(),
        'p_price_start': int.tryParse(priceCtrl.text.trim()) ?? 0,
        'p_vehicle_types': _selectedKeys(vehicleTypes),
        'p_service_types': _selectedKeys(serviceTypes),
        'p_longitude': selectedLocation.value!.longitude,
        'p_latitude': selectedLocation.value!.latitude,
        'p_created_by': _supabase.auth.currentUser!.id,
      },
    );
    return result as String; // RPC return UUID bengkel baru
  }

  // ── Direct Update ─────────────────────────────────────────────────────────
  Future<void> _updateWorkshopDirect() async {
    await _supabase
        .from('workshops')
        .update({
          'name': nameCtrl.text.trim(),
          'description': descCtrl.text.trim(),
          'address': addressCtrl.text.trim(),
          'price_start': int.tryParse(priceCtrl.text.trim()) ?? 0,
          'vehicle_types': _selectedKeys(vehicleTypes),
          'service_types': _selectedKeys(serviceTypes),
          'latitude': selectedLocation.value!.latitude,
          'longitude': selectedLocation.value!.longitude,
          'updated_at': DateTime.now().toIso8601String(),
        })
        .eq('id', editingWorkshop!.id);
  }

  // ── Insert Photo Records ──────────────────────────────────────────────────
  Future<void> _insertPhotoRecords(String workshopId, List<String> urls) async {
    final existing = existingPhotoUrls.length; // jumlah foto lama tersisa
    final rows = urls
        .asMap()
        .entries
        .map(
          (e) => {
            'workshop_id': workshopId,
            'photo_url': e.value,
            // is_primary hanya true jika tidak ada foto lama sama sekali
            // dan ini foto pertama dari upload baru
            'is_primary': existing == 0 && e.key == 0,
          },
        )
        .toList();

    await _supabase.from('workshop_photos').insert(rows);
  }

  // ── Submit (Orkestrasi Insert & Edit) ─────────────────────────────────────
  Future<void> submitWorkshop() async {
    if (selectedLocation.value == null) {
      Get.snackbar(
        'Lokasi belum dipilih',
        'Silakan klik lokasi bengkel pada peta',
        icon: const Icon(Icons.location_off, color: Colors.white),
        backgroundColor: Colors.orange.shade700,
        colorText: Colors.white,
      );
      return;
    }

    isLoading.value = true;

    try {
      String workshopId;

      if (isEditMode) {
        // Mode Edit: update langsung + bersihkan foto yang dihapus
        workshopId = editingWorkshop!.id;
        await Future.wait([_updateWorkshopDirect(), _commitRemovedPhotos()]);
      } else {
        // Mode Tambah: panggil RPC untuk dapat UUID
        workshopId = await _insertWorkshopRpc();
      }

      // Upload foto baru (paralel) lalu simpan record-nya
      if (selectedImages.isNotEmpty) {
        final urls = await Future.wait(
          selectedImages.map((img) => _uploadImage(img, workshopId)),
        );
        await _insertPhotoRecords(workshopId, urls);
      }

      Get.snackbar(
        'Berhasil! 🎉',
        isEditMode
            ? 'Data "${nameCtrl.text}" berhasil diperbarui'
            : '"${nameCtrl.text}" berhasil ditambahkan',
        backgroundColor: Colors.green.shade600,
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );

      // Kembali ke dashboard dengan sinyal refresh (result: true)
      Get.back(result: true);
    } on PostgrestException catch (e) {
      Get.snackbar('Database Error', e.message);
    } on StorageException catch (e) {
      Get.snackbar('Upload Gagal', e.message);
    } catch (e) {
      Get.snackbar('Error', '$e');
    } finally {
      isLoading.value = false;
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  void toggleVehicle(String key) =>
      vehicleTypes[key] = !(vehicleTypes[key] ?? false);

  void toggleService(String key) =>
      serviceTypes[key] = !(serviceTypes[key] ?? false);

  List<String> _selectedKeys(Map<String, bool> map) =>
      map.entries.where((e) => e.value).map((e) => e.key).toList();
}
